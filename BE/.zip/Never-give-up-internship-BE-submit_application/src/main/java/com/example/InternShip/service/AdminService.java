package com.example.InternShip.service;

public interface AdminService {
    void BanUser(int id);
    void UnBanUser(int id);
}
