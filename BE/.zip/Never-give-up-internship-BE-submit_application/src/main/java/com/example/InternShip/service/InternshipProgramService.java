package com.example.InternShip.service;

import java.util.List;

import com.example.InternShip.entity.InternshipProgram;

public interface InternshipProgramService {
    
    public List<InternshipProgram> getAllPrograms();
}
