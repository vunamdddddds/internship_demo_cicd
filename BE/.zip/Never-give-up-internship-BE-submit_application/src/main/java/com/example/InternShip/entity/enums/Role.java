package com.example.InternShip.entity.enums;

public enum Role {
    ADMIN,
    MENTOR,
    INTERN,
    HR,
    VISITOR
}
