package com.example.InternShip.dto.response;



import lombok.Data;

@Data
public class GetAllInternProgram {
    private Integer id;
 
}
