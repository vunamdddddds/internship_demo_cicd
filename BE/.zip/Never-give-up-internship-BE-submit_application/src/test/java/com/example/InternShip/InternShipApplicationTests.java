package com.example.InternShip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternShipApplicationTests {

	@Test
	void contextLoads() {
	}

}
